﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Почта
{
    public partial class Form1 : Form
    {
        Pochta ad = new Pochta();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Заполните пустые поля");
            }
            else
            {
                ad.ChangeSt(textBox1.Text);
                ad.ChangeCit(textBox2.Text);
                ad.ChangePos(textBox3.Text);

                string filePath = "file1.txt";
                string[] s = File.ReadAllLines(filePath);
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i].Contains(listBox1.Text))
                    {
                       s[i] = $"Улица: {textBox1.Text}, Город: {textBox2.Text}, Код: {textBox3.Text}";
                    }
                }
                File.WriteAllLines(filePath, s);
            }
        
    }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (File.Exists("file1.txt"))
            {
                StreamReader sw = File.OpenText("file1.txt");
                while (!sw.EndOfStream)
                {
                    string st = sw.ReadLine();
                    listBox1.Items.Add(st);
                }
                sw.Close();
            }
            else
            {
                MessageBox.Show("Файла нет");
            }
            button2.Enabled = false;
        }
    }
}
